const cart = [];
const cartItems = document.getElementById('cart-items');
const totalPriceElement = document.getElementById('total-price');


document.querySelectorAll('.add-to-cart').forEach(button => {
    button.addEventListener('click', () => {
        const productName = button.getAttribute('data-name');
        const productPrice = parseFloat(button.getAttribute('data-price'));

        cart.push({ name: productName, price: productPrice });
        updateCart();
    });
});


function updateCart() {
    cartItems.innerHTML = '';
    let total = 0;

    cart.forEach(item => {
        const li = document.createElement('li');
        li.textContent = `${item.name} - $${item.price.toFixed(2)}`;
        cartItems.appendChild(li);
        total += item.price;
    });

    totalPriceElement.textContent = `Total: $${total.toFixed(2)}`;
}


document.getElementById('checkout').addEventListener('click', () => {
    if (cart.length === 0) {
        alert('Your cart is empty!');
    } else {
        alert('Thank you for your purchase!');
        cart.length = 0;
        updateCart();
    }
});
